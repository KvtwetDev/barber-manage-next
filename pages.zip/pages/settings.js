import React from 'react'
import Layout from './layout'

export default function Settings() {
    return (
        <Layout>
            <div>
                <h2>Settings</h2>
            </div>
        </Layout>
    )
}
