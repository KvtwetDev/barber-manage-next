import React from 'react'
import Layout from './layout'

export default function Admin() {
    return (
        <Layout>
            <div>
                <h2>Admin</h2>
            </div>
        </Layout>
    )
}
